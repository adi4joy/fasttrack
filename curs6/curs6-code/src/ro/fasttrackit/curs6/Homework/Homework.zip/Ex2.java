package ro.fasttrackit.curs6.Homework;

public class Ex2 {
    public static void main(String[] args) {
        System.out.println("The returned sum is " + numbers(12, 5));
    }

    public static int numbers(int number1, int number2) {
        int sum = number1 + number2;
        return sum;
    }
}
