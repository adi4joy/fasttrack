package ro.fasttrackit.curs6.Homework;

public class Ex1 {
    public static void main(String[] args) {
        writeHello();
    }

    public static void writeHello() {
        String phrase = "Hello 2020";
        System.out.println(phrase);
    }
}
